import logo from './logo.svg';
import './App.css';
import BasicExample from './Add';
import { useSelector } from 'react-redux';
import { Registration } from './component/Registration';

function App() {
  const products=useSelector(state=>state.products)

  const users=useSelector(state=>state.users)
  return (
    <div className="App">
      {/* <BasicExample /> */}
      {
        products.map(product=>
          <div key={product.id} >
              {product.name} - {product.price}
            </div>
          )
      }
      {
        users.map(user=>
          <div key={user.id} >
              {user.name} - {user.username}
            </div>
          )
      }
      <Registration />
    </div>
  );
}

export default App;
